﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace BaedalFriend
{
    class Regstry
    {
        public Regstry()
        {

        }

        public void setBrowser()
        { 
            if (Environment.Is64BitOperatingSystem) // 운영체제 종류 확인 (64비트)
            {

                Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Internet Explorer\MAIN\FeatureControl\FEATURE_BROWSER_EMULATION", Properties.Settings.Default.ProductName + ".exe", 11001);
                Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Internet Explorer\MAIN\FeatureControl\FEATURE_BROWSER_EMULATION", Properties.Settings.Default.ProductName + ".vshost.exe", 11001);

            }
            else
            {  //For 32 bit machine

                Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", Properties.Settings.Default.ProductName + ".exe", 11001);
                Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", Properties.Settings.Default.ProductName + ".vshost.exe", 11001);

            }
        }

        //public enum regType
        //{
        //    HKEY_CLASSES_ROOT,
        //    HKEY_CURRENT_CONFIG,
        //    HKEY_CURRENT_USER,
        //    HKEY_LOCAL_MACHINE,
        //    HKEY_PERFORMANCE_DATA,
        //    HKEY_USERS
        //}


        //internal string GetRegistry(regType type, string path, string key)
        //{
        //    RegistryKey rKey = null;

        //    switch (type)
        //    {
        //        case regType.HKEY_CLASSES_ROOT:
        //            rKey = Registry.ClassesRoot.OpenSubKey(path);
        //            break;
        //        case regType.HKEY_CURRENT_CONFIG:
        //            rKey = Registry.CurrentConfig.OpenSubKey(path);
        //            break;
        //        case regType.HKEY_CURRENT_USER:
        //            rKey = Registry.CurrentUser.OpenSubKey(path);
        //            break;
        //        case regType.HKEY_LOCAL_MACHINE:

        //            rKey = Registry.LocalMachine.OpenSubKey(path);
        //            break;
        //        case regType.HKEY_PERFORMANCE_DATA:
        //            rKey = Registry.PerformanceData.OpenSubKey(path);
        //            break;
        //        case regType.HKEY_USERS:
        //            rKey = Registry.Users.OpenSubKey(path);
        //            break;
        //        default:
        //            return "";
        //    }
        //    return string.IsNullOrEmpty((string)rKey.GetValue(key)) ? "" : (string)rKey.GetValue(key);

        //}
        //internal void SetRegistry(regType type, string key, Dictionary<string, object> value)
        //{
        //    RegistryKey rKey = null;

        //    switch (type)
        //    {
        //        case regType.HKEY_CLASSES_ROOT:
        //            rKey = Registry.ClassesRoot.OpenSubKey(key, true);
        //            break;
        //        case regType.HKEY_CURRENT_CONFIG:
        //            rKey = Registry.CurrentConfig.OpenSubKey(key, true);
        //            break;
        //        case regType.HKEY_CURRENT_USER:
        //            rKey = Registry.CurrentUser.OpenSubKey(key, true);
        //            break;
        //        case regType.HKEY_LOCAL_MACHINE:
        //            rKey = Registry.LocalMachine.OpenSubKey(key, true);
        //            break;
        //        case regType.HKEY_PERFORMANCE_DATA:
        //            rKey = Registry.PerformanceData.OpenSubKey(key, true);
        //            break;
        //        case regType.HKEY_USERS:
        //            rKey = Registry.Users.OpenSubKey(key, true);
        //            break;
        //        default:
        //            return;
        //    }

        //    foreach (var item in value)
        //    {
        //        rKey.SetValue(item.Key, item.Value);
        //    }
        //    rKey.Close();
        //}

    }
}
