﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;

namespace BaedalFriend
{
    public partial class store : Form
    {

        public store()
        {
            InitializeComponent();
            Regstry reg = new Regstry();
            reg.setBrowser();
        }

        private void store_Load(object sender, EventArgs e)
        {
            //this.storeWebview.Navigate("https://flugbf.kr/page/application/my_store_sel.php?app_mb_id="+BaedalItemList.mb_id);
        }

        public void LoadStore()
        {
            this.storeWebview.Navigate("https://flugbf.kr/page/application/my_store_sel.php?app_mb_id=" + BaedalItemList.mb_id);
        }
    }
}
