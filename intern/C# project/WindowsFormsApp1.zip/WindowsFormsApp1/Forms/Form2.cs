﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend;
using BaedalFriend.Model;
using System.Net;
using System.Net.Sockets;
using BaedalFriend.socket.client;
using System.Threading;

namespace BaedalFriend
{
    public partial class Form2 : Form
    {
        public string[] _ipconnect { get; set; }

        public Form2()
        {
            InitializeComponent();
        }
    
        private void Form2_Load(object sender, EventArgs e)
        {
            BaedalItemList.orderfrm = new order();
            BaedalItemList.storefrm = new store();
            BaedalItemList.register = new register();

            BaedalItemList.orderfrm.TopLevel = false;
            BaedalItemList.storefrm.TopLevel = false;
            BaedalItemList.register.TopLevel = false;


            //BaedalItemList.orderfrm.WindowState = FormWindowState.Maximized;
            //BaedalItemList.storefrm.WindowState = FormWindowState.Maximized;
            //BaedalItemList.register.WindowState = FormWindowState.Maximized;

            viewContainer.Controls.Add(BaedalItemList.orderfrm);
            viewContainer.Controls.Add(BaedalItemList.storefrm);
            viewContainer.Controls.Add(BaedalItemList.register);

            BaedalItemList.orderfrm.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            this.notiIcon.Visible = false;

            //로그인아이디 삭제
            BaedalItemList.mb_id = "";
            //소캣 연결 해제..
            if (BaedalItemList.socket != null)
            {
                BaedalItemList.socket.Disconnect(true);
            }

            BaedalItemList.frmLogin.Show();
        }

        //주문관리
        private void orderBtn_Click(object sender, EventArgs e)
        {
            BaedalItemList.orderfrm.Show();
            BaedalItemList.orderfrm.LoadOrder();
            //BaedalItemList.orderfrm.WindowState = FormWindowState.Maximized;
            BaedalItemList.storefrm.Hide();
            BaedalItemList.register.Hide();
            //orderfrm.WindowState = FormWindowState.Maximized
        }
        
        //회원정보수정
        private void accountBtn_Click(object sender, EventArgs e)
        {
            BaedalItemList.orderfrm.Hide();
            BaedalItemList.storefrm.Hide();
            BaedalItemList.register.Show();
            //BaedalItemList.register.WindowState = FormWindowState.Maximized;
            BaedalItemList.register.LoadRegister();
        }
        
        //상점관리
        private void storeBtn_Click(object sender, EventArgs e)
        {
            BaedalItemList.orderfrm.Hide();
            BaedalItemList.register.Hide();
            BaedalItemList.storefrm.Show();
            //BaedalItemList.storefrm.WindowState = FormWindowState.Maximized;
            BaedalItemList.storefrm.LoadStore();
            //storefrm.WindowState = FormWindowState.Maximized;
        }

        public void alarm(string _msg)
        {
            //MessageBox.Show(_msg, "전송메시지");
            /*BaedalItemList.popAlarm._strMsg = _msg;
            BaedalItemList.popAlarm.TopLevel = true;

            BaedalItemList.popAlarm.ShowDialog();*/
            //BaedalItemList.orderfrm.Show();
            //BaedalItemList.orderfrm.LoadOrder();
            //BaedalItemList.storefrm.Hide();

            Thread popThread = new Thread(() => pop_Alarm(_msg));
            popThread.SetApartmentState(ApartmentState.STA);
            popThread.Start();
        }

        public void pop_Alarm(string _msg)
        {
            //알림이 뜨고 10분 타이머 시작
            Form alarm = new Forms.Popup.popup_alarm
            {
                _strMsg = _msg
            };
            alarm.TopLevel = true;
            alarm.ShowDialog();
        
           
        }
        
        private void MenuStrip_exit_Click(object sender, EventArgs e)
        {
            this.Close();
            this.notiIcon.Visible = false;
            Application.Exit();
        }

        private void MenuStrip_full_Click(object sender, EventArgs e)
        {
            this.notiIcon.Visible = false;
            this.Show();
        }

        private void notiIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.notiIcon.Visible = false;
            this.Show();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
           if (e.CloseReason == CloseReason.UserClosing)
            {
                this.notiIcon.Visible = true;
                this.Hide();
                e.Cancel = true;
            }
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            this.notiIcon.Visible = true;
            this.Hide();
        }

        private void print_set_Click(object sender, EventArgs e)
        {
            Form setPrint = new Forms.Popup.settingPrint();
            setPrint.TopLevel = true;
            setPrint.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (MessageBox.Show("링크로 연결되는 페이지 접속후 프로그램을 다운로드 및 설치 후 청주배프 개발팀으로 연락 바랍니다.\r\n페이지로 이동 하시겠습니까?", "확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("https://www.teamviewer.com/ko/");
            }
        }

    }
}
