﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;

namespace BaedalFriend
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
            Regstry reg = new Regstry();
            reg.setBrowser();
        }

        private void register_Load(object sender, EventArgs e)
        {

        }

        public void LoadRegister()
        {
            this.registerWebView.Navigate("https://flugbf.kr/bbs/register_form.php?w=u&type=application&mb_id=" + BaedalItemList.mb_id +"&app_mb_id="+BaedalItemList.mb_id);
        }
    }
}
