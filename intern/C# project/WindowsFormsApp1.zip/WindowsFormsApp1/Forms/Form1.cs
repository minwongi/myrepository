﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using BaedalFriend.socket.client;
using BaedalFriend.Model;

namespace BaedalFriend
{
    public partial class Form1 : Form
    {
        public static String Server = "Server=211.110.229.204; Uid=flug; Database=giveyou; Pwd=flug0258; Port=3306";
        private MySqlConnection mConnection;
        private MySqlCommand mCommand;
        private MySqlDataReader mDataReader;
        
        public Form1()
        {
            InitializeComponent();
            //this.loginBtn.Click += loginBtn_Click;
            this.mb_id.KeyDown += login_KeyDown;
            this.mb_pass.KeyDown += login_KeyDown;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.mb_id.Text = "";
            this.mb_pass.Text = "";
        }

        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                loginCheck();
            }
        }
        
        private void loginBtn_Click(object sender, EventArgs e)
        {
            loginCheck();   
        }
        
        private void loginCheck()
        {

            mConnection = new MySqlConnection(Server); // DB접속

            if (String.IsNullOrEmpty(mb_id.Text))
            {
                login_info.Text = "아이디를 입력해주세요.";
                return;
            }
            if (String.IsNullOrEmpty(mb_pass.Text))
            {
                login_info.Text = "비밀번호를 입력해주세요.";
                return;
            }


            try
            {
                mConnection.Open();

                string sql = "select mb_password,mb_password2,mb_level,member_type from g5_member where mb_id = '" + mb_id.Text + "'";
                mCommand = new MySqlCommand(sql, mConnection);
                mDataReader = mCommand.ExecuteReader();

                if (mDataReader.Read())
                {
                    string mb_pass = this.mb_pass.Text;
                    string chk_pass = mDataReader["mb_password"].ToString();
                    string chk_pass2 = mDataReader["mb_password2"].ToString();
                    int mb_level = Int32.Parse(mDataReader["mb_level"].ToString());
                    int member_type = Int32.Parse(mDataReader["member_type"].ToString());

               
                    if (mb_level != 5)
                    {
                        login_info.Text = "상점관리자가 아닙니다.";
                        return;
                    }
                    else
                    {
                        if (member_type == 1)
                        {
                            login_info.Text = "부계정은 사용할 수 없습니다.";
                            return;
                        }
                    }

                    mDataReader.Close();

                    if (chk_pass.Length > 41)
                    {
                        //예전 로그인
                        string sqlpass = "select password('" + mb_pass + "') as pass";
                        mCommand = new MySqlCommand(sqlpass, mConnection);
                        mDataReader = mCommand.ExecuteReader();

                        if (mDataReader.Read())
                        {
                            if (mDataReader["pass"].Equals(chk_pass2))
                            {
                                BaedalItemList.mb_id = mb_id.Text;
                                //this.login_info.Text = "회원정보 일치";
                                //this.Close();


                                /***************************/
                                string[] ipconnect = new string[3];

                                ipconnect[0] = "221.160.74.28";
                                ipconnect[1] = "40001";
                                ipconnect[2] = mb_id.Text;
                                                                
                                BaedalItemList.client = new connect(ipconnect);
                                /***************************/

                                BaedalItemList.frmMain._ipconnect = ipconnect;
                                BaedalItemList.frmMain.Show();
                                BaedalItemList.frmLogin.Hide();
                            }
                            else
                            {
                                this.login_info.Text = "회원정보 불일치1";
                            }
                        }
                    }
                    else
                    {
                        //예전 로그인
                        string sqlpass = "select password('" + mb_pass + "') as pass";
                        mCommand = new MySqlCommand(sqlpass, mConnection);
                        mDataReader = mCommand.ExecuteReader();

                        if (mDataReader.Read())
                        {
                            if (mDataReader["pass"].Equals(chk_pass))
                            {
                                BaedalItemList.mb_id = mb_id.Text;
                                //this.login_info.Text = "회원정보 일치";
                                //this.Close();
                                Form2 frm2 = new Form2();
                                frm2.Show();

                                /***************************/
                                //Socket 연결 Test
                                string[] ipconnect = new string[3];

                                ipconnect[0] = "221.160.74.28";
                                ipconnect[1] = "40001";
                                ipconnect[2] = mb_id.Text;

                                BaedalItemList.client = new connect(ipconnect);
                                
                                /***************************/
                                BaedalItemList.frmMain._ipconnect = ipconnect;
                                BaedalItemList.frmMain.Show();
                                BaedalItemList.frmLogin.Hide();
                            }
                            else
                            {
                                this.login_info.Text = "회원정보 불일치2";
                            }
                        }
                    }
                }

                mConnection.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                login_info.Text = ex.Message;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (MessageBox.Show("링크로 연결되는 페이지 접속후 프로그램을 다운로드 및 설치 후 청주배프 개발팀으로 연락 바랍니다.\r\n페이지로 이동 하시겠습니까?", "확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("https://www.teamviewer.com/ko/");
            }
        }
    }
}
