﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;
using MySql.Data.MySqlClient;

namespace BaedalFriend
{
    public partial class order : Form
    {

        public static String Server = "Server=211.110.229.204; Uid=flug; Database=giveyou; Pwd=flug0258; Port=3306";
        private MySqlConnection mConnection;
        private MySqlCommand mCommand;
        private MySqlDataReader mDataReader;

        public order()
        {
            InitializeComponent();

            searchCate.Items.Add("주문번호");
            searchCate.Items.Add("주문자명");
            searchCate.Items.Add("연락처");
            searchCate.Items.Add("배송지");
            
            searchCate.SelectedIndex = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void order_Load(object sender, EventArgs e)
        {
            LoadOrder();

            /*System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000 * 5; //1분
            timer.Tick += new EventHandler(LoadOrder2);
            timer.Start();*/
        }

        private void SetHeight(ListView LV, int height)
        {
            // listView 높이 지정
            ImageList imgList = new ImageList();
            imgList.ImageSize = new Size(1, height);
            LV.SmallImageList = imgList;
        }

        public void LoadOrder()
        {

            //초기화
            string[] menu_name = null;
            string[] menu_count = null;
            string[] menu_price = null;

            string stx = this.searchText.Text.ToString();
            try
            {
                string sfl = this.searchCate.SelectedItem.ToString();
      
                this.order_list.Clear();

                this.order_list.View = View.Details;

                order_list.FullRowSelect = true;

                this.order_list.Columns.Add("번호",80);
                this.order_list.Columns.Add("상태",80);
                this.order_list.Columns.Add("상점명",80);
                this.order_list.Columns.Add("주문번호",160);
                this.order_list.Columns.Add("메뉴",100);
                this.order_list.Columns.Add("배달지", 500);
                this.order_list.Columns.Add("주문자명", 80);
                this.order_list.Columns.Add("연락처", 150);
                this.order_list.Columns.Add("메뉴금액", 100);
                this.order_list.Columns.Add("배달비", 100);
                this.order_list.Columns.Add("할인비", 100);
                this.order_list.Columns.Add("총결제금액", 100);
                this.order_list.Columns.Add("결제방식", 120);
                this.order_list.Columns.Add("배달예상시간", 50);
                this.order_list.Columns.Add("상점요청사항", 150);
                this.order_list.Columns.Add("배달요청사항", 150);

                //주문목록 가져오기
                mConnection = new MySqlConnection(Server); // DB접속
                mConnection.Open();

                string sql = "";
                if (!String.IsNullOrEmpty(stx))
                {

                    string search_sql = "";
                    switch (sfl)
                    {
                        case "주문번호":
                            search_sql = " and o.order_number like '%"+stx+"%'";
                            break;
                        case "주문자명":
                            search_sql = " and b.mb_name like '%"+stx+"%'";
                            break;
                        case "연락처":
                            string st = stx.Replace("-", "");
                            search_sql = " and (b.mb_hp like '%"+stx+ "%' or o.order_user_phone like '%"+stx+ "%' or b.mb_hp like '%" + st + "%' or o.order_user_phone like '%" + st + "%' )";
                            break;
                        case "배송지":
                            search_sql = " and (o.order_recive_addr1 like '%"+stx+ "%' or o.order_recive_addr2 like '%"+stx+ "%' or o.order_recive_addr3 like '%"+stx+"%')";
                            break;
                    }
                    sql = "select *,o.mb_id as order_mb_id, w.mb_id as store_mb_id,b.mb_id as mb_id from order_form as o left join store_detail as d on o.wr_id = d.wr_id left join g5_write_main as w on w.wr_id = d.wr_id left join g5_member as b on b.mb_id= o.mb_id where w.mb_id = '" + BaedalItemList.mb_id + "'" + search_sql + " order by  o.order_date desc , o.order_state, o.delivery_state";
                }
                else
                {
                    sql = "select *,o.mb_id as order_mb_id, w.mb_id as store_mb_id,b.mb_id as mb_id from order_form as o left join store_detail as d on o.wr_id = d.wr_id left join g5_write_main as w on w.wr_id = d.wr_id left join g5_member as b on b.mb_id= o.mb_id where w.mb_id = '" + BaedalItemList.mb_id + "' order by  o.order_date desc , o.order_state, o.delivery_state";
                }

                Console.WriteLine(sql);
                mCommand = new MySqlCommand(sql, mConnection);
                mDataReader = mCommand.ExecuteReader();

                if (mDataReader.HasRows)
                {
                    while (mDataReader.Read())
                    {
                        string status = "접수대기";

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("0"))
                        {
                            status = "주문접수";
                        }

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("1"))
                        {
                            status = "배송중";
                        }

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("2"))
                        {
                            status = "배송완료";
                        }

                        if (mDataReader["order_cancel_status"].ToString().Contains("1"))
                        {
                            status = "주문취소";
                        }

                        menu_name = mDataReader["order_menu"].ToString().Split(new string[] { "," },StringSplitOptions.None);
                        menu_count= mDataReader["order_count"].ToString().Split(new string[] { "," },StringSplitOptions.None);
                        menu_price = mDataReader["order_price"].ToString().Split(new string[] { "," },StringSplitOptions.None);


                        string menu = ""; 
                        int mPrice = 0;
                        int totalPrice = 0;
                        int dicount_price = Int32.Parse(mDataReader["discount_price"].ToString());
                        int delivery_price = Int32.Parse(mDataReader["delivery_price"].ToString());
                        int order_total_price = Int32.Parse(mDataReader["order_total_price"].ToString());

                        string[] options = new string[menu_name.Length];
                        //Console.WriteLine(mDataReader["order_option"].ToString());

                        if (!String.IsNullOrEmpty(mDataReader["order_option"].ToString().Trim()))
                        {
                            string[] menu_options = mDataReader["order_option"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                            string[] menu_options_price = mDataReader["order_option_price"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                            //Console.WriteLine(menu_options.Length);
                           
                            if (menu_options.Length > 0)
                            {
                                for (int i = 0; i < menu_name.Length; i++)
                                {
                                    if (!String.IsNullOrEmpty(menu_options[i]))
                                    {
                                        string[] menu_option_detail = menu_options[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                        string[] menu_options_prices = menu_options_price[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                        for (int j = 0; j < menu_option_detail.Length; j++)
                                        {
                                            options[i] += menu_option_detail[j];
                                            if (menu_option_detail.Length != j + 1)
                                            {
                                                options[i] += ",";
                                            }
                                            //optPrice += Int32.Parse(menu_options_prices[j]);
                                        }
                                    }
                                    else
                                    {
                                        options[i] = null;
                                    }
                                }

                                for (int i = 0; i < menu_name.Length; i++)
                                {
                                    menu += menu_name[i] + " - " + menu_count[i] + "개";
                                    if (!String.IsNullOrEmpty(options[i]))
                                    {
                                        menu += " : "+options[i];
                                    }
                                    if (menu_name.Length != i + 1)
                                    {
                                        //Console.WriteLine(menu + "//줄바꿈");
                                        menu += ", \r\n";
                                    }
                                    mPrice += Int32.Parse(menu_price[i].ToString()) * Int32.Parse(menu_count[i]);
                                }
                            }
                        }
                        else
                        {
                            for (int i = 0; i < menu_name.Length; i++)
                            {
                                menu += menu_name[i] + " - " + menu_count[i] + "개";
                                if (menu_name.Length != i + 1)
                                {
                                    menu += ", \r\n";
                                }
                                mPrice += Int32.Parse(menu_price[i].ToString()) * Int32.Parse(menu_count[i]);
                            }
                        }
                        totalPrice = order_total_price + delivery_price - dicount_price;
                        
                        ListViewItem item = new ListViewItem(mDataReader["order_id"].ToString());//주문아이디
                        item.SubItems.Add(status);//상태
                        if (status.Contains("주문취소"))
                        {
                            item.SubItems[0].ForeColor = Color.LightGray;
                            item.SubItems[0].Font = new Font("굴림",9,FontStyle.Bold);
                            //item.Font = new 
                        }else if (status.Contains("접수대기"))
                        {
                            item.SubItems[0].ForeColor = Color.Red;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("주문접수"))
                        {
                            item.SubItems[0].ForeColor = Color.OrangeRed;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("배송완료"))
                        {
                            item.SubItems[0].ForeColor = Color.Black;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("배송중"))
                        {
                            item.SubItems[0].ForeColor = Color.Blue;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }

                        item.SubItems.Add(mDataReader["wr_subject"].ToString());//상점명
                        item.SubItems.Add(mDataReader["order_number"].ToString());//주문번호
                        item.SubItems.Add(menu);//메뉴목록
                        item.SubItems.Add(mDataReader["order_recive_addr1"].ToString() + " " +mDataReader["order_recive_addr2"].ToString() + " " + mDataReader["order_recive_addr3"].ToString());//배송지
                        item.SubItems.Add(mDataReader["mb_name"].ToString());//주문자 연락처
                        item.SubItems.Add(mDataReader["order_user_phone"].ToString());//주문자 연락처
                        //item.SubItems.Add(mDataReader["order_total_price"].ToString());//총금액
                        item.SubItems.Add(order_total_price + "원");//메뉴금액
                        item.SubItems.Add(delivery_price + "원");//배달비
                        if (dicount_price == 0)
                        {
                            item.SubItems.Add(dicount_price + "원");//할인비
                        }
                        else
                        {
                            item.SubItems.Add("-" + dicount_price + "원");//할인비
                        }
                        item.SubItems.Add(totalPrice.ToString() + "원");//총금액
                        item.SubItems.Add(mDataReader["order_type2"].ToString());//주문결제방식
                        //item.SubItems.Add(mDataReader["order_date"].ToString());//주문일
                        //item.SubItems.Add(mDataReader["order_confirm_date"].ToString());//주문접수시간
                        item.SubItems.Add(mDataReader["delivery_time"].ToString());//배달예상시간
                        //item.SubItems.Add(mDataReader["delivery_date"].ToString());//배달시작시간
                        //item.SubItems.Add(mDataReader["order_fin_date"].ToString());//배달완료시간
                        item.SubItems.Add(mDataReader["order_shop_msg"].ToString());
                        item.SubItems.Add(mDataReader["order_driver_msg"].ToString());

                        this.order_list.Items.Add(item);
                    }
                }
                else
                {
                    MessageBox.Show("데이터가 없습니다");
                }
                SetHeight(this.order_list, 80);

                mDataReader.Close();
                mConnection.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            //this.orderWebView.Navigate("https://flugbf.kr/page/application/order_list.php?app_mb_id=" + BaedalItemList.mb_id);
        }

        public void LoadOrder2(object sender, EventArgs e)
        {

            //초기화
            string[] menu_name = null;
            string[] menu_count = null;
            string[] menu_price = null;

            string stx = this.searchText.Text.ToString();
            string sfl = this.searchCate.SelectedItem.ToString();

            this.order_list.Clear();

            this.order_list.View = View.Details;

            order_list.FullRowSelect = true;

            this.order_list.Columns.Add("번호", 80);
            this.order_list.Columns.Add("상태", 80);
            this.order_list.Columns.Add("상점명", 80);
            this.order_list.Columns.Add("주문번호", 160);
            this.order_list.Columns.Add("메뉴", 100);
            this.order_list.Columns.Add("배달지", 500);
            this.order_list.Columns.Add("주문자명", 80);
            this.order_list.Columns.Add("연락처", 150);
            this.order_list.Columns.Add("메뉴금액", 100);
            this.order_list.Columns.Add("배달비", 100);
            this.order_list.Columns.Add("할인비", 100);
            this.order_list.Columns.Add("총결제금액", 100);
            this.order_list.Columns.Add("결제방식", 120);
            this.order_list.Columns.Add("배달예상시간", 50);
            this.order_list.Columns.Add("상점요청사항", 150);
            this.order_list.Columns.Add("배달요청사항", 150);

            //주문목록 가져오기
            mConnection = new MySqlConnection(Server); // DB접속

            try
            {
                mConnection.Open();

                string sql = "";
                if (!String.IsNullOrEmpty(stx))
                {
                    Console.WriteLine("검색있음");

                    string search_sql = "";
                    switch (sfl)
                    {
                        case "주문번호":
                            search_sql = " and o.order_number like '%" + stx + "%'";
                            break;
                        case "주문자명":
                            search_sql = " and b.mb_name like '%" + stx + "%'";
                            break;
                        case "연락처":
                            string st = stx.Replace("-", "");
                            search_sql = " and (b.mb_hp like '%" + stx + "%' or o.order_user_phone like '%" + stx + "%' or b.mb_hp like '%" + st + "%' or o.order_user_phone like '%" + st + "%' )";
                            break;
                        case "배송지":
                            search_sql = " and (o.order_recive_addr1 like '%" + stx + "%' or o.order_recive_addr2 like '%" + stx + "%' or o.order_recive_addr3 like '%" + stx + "%')";
                            break;
                    }
                    sql = "select *,o.mb_id as order_mb_id, w.mb_id as store_mb_id,b.mb_id as mb_id from order_form as o left join store_detail as d on o.wr_id = d.wr_id left join g5_write_main as w on w.wr_id = d.wr_id left join g5_member as b on b.mb_id= o.mb_id where w.mb_id = '" + BaedalItemList.mb_id + "'" + search_sql + " order by  o.order_date desc , o.order_state, o.delivery_state";
                }
                else
                {
                    Console.WriteLine("검색없음");
                    sql = "select *,o.mb_id as order_mb_id, w.mb_id as store_mb_id,b.mb_id as mb_id from order_form as o left join store_detail as d on o.wr_id = d.wr_id left join g5_write_main as w on w.wr_id = d.wr_id left join g5_member as b on b.mb_id= o.mb_id where w.mb_id = '" + BaedalItemList.mb_id + "' order by  o.order_date desc , o.order_state, o.delivery_state";
                }

                Console.WriteLine(sql);
                mCommand = new MySqlCommand(sql, mConnection);
                mDataReader = mCommand.ExecuteReader();

                if (mDataReader.HasRows)
                {
                    while (mDataReader.Read())
                    {
                        string status = "접수대기";

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("0"))
                        {
                            status = "주문접수";
                        }

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("1"))
                        {
                            status = "배송중";
                        }

                        if (mDataReader["order_state"].ToString().Contains("2") && mDataReader["delivery_state"].ToString().Contains("2"))
                        {
                            status = "배송완료";
                        }

                        if (mDataReader["order_cancel_status"].ToString().Contains("1"))
                        {
                            status = "주문취소";
                        }

                        menu_name = mDataReader["order_menu"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                        menu_count = mDataReader["order_count"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                        menu_price = mDataReader["order_price"].ToString().Split(new string[] { "," }, StringSplitOptions.None);


                        string menu = "";
                        int mPrice = 0;
                        int totalPrice = 0;
                        int dicount_price = Int32.Parse(mDataReader["discount_price"].ToString());
                        int delivery_price = Int32.Parse(mDataReader["delivery_price"].ToString());
                        int order_total_price = Int32.Parse(mDataReader["order_total_price"].ToString());

                        string[] options = new string[menu_name.Length];
                        //Console.WriteLine(mDataReader["order_option"].ToString());

                        if (!String.IsNullOrEmpty(mDataReader["order_option"].ToString().Trim()))
                        {
                            string[] menu_options = mDataReader["order_option"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                            string[] menu_options_price = mDataReader["order_option_price"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                            //Console.WriteLine(menu_options.Length);

                            if (menu_options.Length > 0)
                            {
                                for (int i = 0; i < menu_name.Length; i++)
                                {
                                    if (!String.IsNullOrEmpty(menu_options[i]))
                                    {
                                        string[] menu_option_detail = menu_options[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                        string[] menu_options_prices = menu_options_price[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                        for (int j = 0; j < menu_option_detail.Length; j++)
                                        {
                                            options[i] += menu_option_detail[j];
                                            if (menu_option_detail.Length != j + 1)
                                            {
                                                options[i] += ",";
                                            }
                                            //optPrice += Int32.Parse(menu_options_prices[j]);
                                        }
                                    }
                                    else
                                    {
                                        options[i] = null;
                                    }
                                }

                                for (int i = 0; i < menu_name.Length; i++)
                                {
                                    menu += menu_name[i] + " - " + menu_count[i] + "개";
                                    if (!String.IsNullOrEmpty(options[i]))
                                    {
                                        menu += " : " + options[i];
                                    }
                                    if (menu_name.Length != i + 1)
                                    {
                                        //Console.WriteLine(menu + "//줄바꿈");
                                        menu += ", \r\n";
                                    }
                                    mPrice += Int32.Parse(menu_price[i].ToString()) * Int32.Parse(menu_count[i]);
                                }
                                Console.WriteLine(menu);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < menu_name.Length; i++)
                            {
                                menu += menu_name[i] + " - " + menu_count[i] + "개";
                                if (menu_name.Length != i + 1)
                                {
                                    menu += ", \r\n";
                                }
                                mPrice += Int32.Parse(menu_price[i].ToString()) * Int32.Parse(menu_count[i]);
                            }
                        }
                        totalPrice = order_total_price + delivery_price - dicount_price;

                        ListViewItem item = new ListViewItem(mDataReader["order_id"].ToString());//주문아이디
                        item.SubItems.Add(status);//상태
                        if (status.Contains("주문취소"))
                        {
                            item.SubItems[0].ForeColor = Color.LightGray;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                            //item.Font = new 
                        }
                        else if (status.Contains("접수대기"))
                        {
                            item.SubItems[0].ForeColor = Color.Red;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("주문접수"))
                        {
                            item.SubItems[0].ForeColor = Color.OrangeRed;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("배송완료"))
                        {
                            item.SubItems[0].ForeColor = Color.Black;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }
                        else if (status.Contains("배송중"))
                        {
                            item.SubItems[0].ForeColor = Color.Blue;
                            item.SubItems[0].Font = new Font("굴림", 9, FontStyle.Bold);
                        }

                        item.SubItems.Add(mDataReader["wr_subject"].ToString());//상점명
                        item.SubItems.Add(mDataReader["order_number"].ToString());//주문번호
                        item.SubItems.Add(menu);//메뉴목록
                        item.SubItems.Add(mDataReader["order_recive_addr1"].ToString() + " " + mDataReader["order_recive_addr2"].ToString() + " " + mDataReader["order_recive_addr3"].ToString());//배송지
                        item.SubItems.Add(mDataReader["mb_name"].ToString());//주문자 연락처
                        item.SubItems.Add(mDataReader["order_user_phone"].ToString());//주문자 연락처
                        //item.SubItems.Add(mDataReader["order_total_price"].ToString());//총금액
                        item.SubItems.Add(order_total_price + "원");//메뉴금액
                        item.SubItems.Add(delivery_price + "원");//배달비
                        if (dicount_price == 0)
                        {
                            item.SubItems.Add(dicount_price + "원");//할인비
                        }
                        else
                        {
                            item.SubItems.Add("-" + dicount_price + "원");//할인비
                        }
                        item.SubItems.Add(totalPrice.ToString() + "원");//총금액
                        item.SubItems.Add(mDataReader["order_type2"].ToString());//주문결제방식
                        //item.SubItems.Add(mDataReader["order_date"].ToString());//주문일
                        //item.SubItems.Add(mDataReader["order_confirm_date"].ToString());//주문접수시간
                        item.SubItems.Add(mDataReader["delivery_time"].ToString());//배달예상시간
                        //item.SubItems.Add(mDataReader["delivery_date"].ToString());//배달시작시간
                        //item.SubItems.Add(mDataReader["order_fin_date"].ToString());//배달완료시간
                        item.SubItems.Add(mDataReader["order_shop_msg"].ToString());
                        item.SubItems.Add(mDataReader["order_driver_msg"].ToString());



                        this.order_list.Items.Add(item);
                    }
                }
                else
                {
                    MessageBox.Show("데이터가 없습니다");
                }
                SetHeight(this.order_list, 80);

                mDataReader.Close();
                mConnection.Close();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
            //this.orderWebView.Navigate("https://flugbf.kr/page/application/order_list.php?app_mb_id=" + BaedalItemList.mb_id);
        }

        private void DetailView(object sender, EventArgs e)
        {
            if (order_list.SelectedItems.Count == 1)
            {
                ListView.SelectedListViewItemCollection items = order_list.SelectedItems;

                ListViewItem selItem = items[0];
                string order_id = selItem.SubItems[0].Text;
                string status = selItem.SubItems[1].Text;

                if (status.Contains("접수대기"))
                {
                    Form alarm = new Forms.Popup.popup_alarm
                    {
                        _strMsg = order_id
                    };
                    alarm.TopLevel = true;
                    alarm.ShowDialog();
                }
                else if(status.Contains("배송완료"))
                {
                    Form prder = new Forms.Popup.popup_order
                    {
                        _order_id = order_id
                    };
                    prder.TopLevel = true;
                    prder.ShowDialog();
                }
                else if(status.Contains("주문취소"))
                {
                    Form cancel = new Forms.Popup.popup_cancel2
                    {
                        _order_id = order_id
                    };
                    cancel.TopLevel = true;
                    cancel.ShowDialog();
                }
                else if (status.Contains("주문접수"))
                {
                    Form cancel= new Forms.Popup.popup_cancel
                    {
                        _order_id = order_id
                    };
                    cancel.TopLevel = true;
                    cancel.ShowDialog();
                }
                else if (status.Contains("배송중"))
                {
                    Form deli = new Forms.Popup.popup_order_deli
                    {
                        _order_id = order_id
                    };
                    deli.TopLevel = true;
                    deli.ShowDialog();
                }
                //MessageBox.Show("상점상세보기" + order_id);

                //상태와 주문번호를 넘겨서 상세보기 창 열기
            }
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            //BaedalItemList.popAlarm.po
            //string stx = this.searchText.Text.ToString();
            //string sfl = this.searchCate.SelectedItem.ToString();
            LoadOrder();
        }

        private void search_enter(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //string stx = this.searchText.Text.ToString();
                //string sfl = this.searchCate.SelectedItem.ToString();
                LoadOrder();
            }
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            this.searchText.Text = "";
            LoadOrder();
        }
    }
}
