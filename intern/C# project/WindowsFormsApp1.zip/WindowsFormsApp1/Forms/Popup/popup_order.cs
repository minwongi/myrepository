﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;
using MySql.Data.MySqlClient;
using System.Collections;

namespace BaedalFriend.Forms.Popup
{
    public partial class popup_order : Form
    {

        public static String Server = "Server=211.110.229.204; Uid=flug; Database=giveyou; Pwd=flug0258; Port=3306";
        private MySqlConnection mConnection;
        private MySqlCommand mCommand;
        private MySqlDataReader mDataReader;
        public string _order_id { get; set; }

        public popup_order()
        {
            InitializeComponent();
            Regstry reg = new Regstry();
            reg.setBrowser();
        }

        private void popup_order_Load(object sender, EventArgs e)
        {
            string url = "https://flugbf.kr/page/shop/store_order_detail_application.php?order_id=" + _order_id;

            this.orderWebview.Navigate(url);
        }
        
        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deli_Btn_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(_order_id))
            {
                if (BaedalItemList.m_SerialPort.OpenPort(Properties.Settings.Default.PortNum, 19200))
                {


                    mConnection = new MySqlConnection(Server); // DB접속
                    string[] menu_name = null;
                    string[] menu_count = null;
                    string[] menu_price = null;
                    ArrayList menu = new ArrayList();
                    string orderNumber = "";
                    string storeName = "";
                    string storeNumber = "";
                    string storeAddr = "";
                    string storeCeo = "";
                    string storeTel = "";
                    string orderDate = "";
                    string orderMsg = "";
                    string deliAddr = "";
                    string deliTel = "";
                    string deliMsg = "";
                    string payType = "";
                    int totalPrice = 0;
                    int dicountPrice = 0;
                    int deliveryPrice = 0;
                    try
                    {
                        mConnection.Open();

                        string sql = "select " +
                            "order_number,order_date,order_menu,order_count,order_price,order_option,order_option_price,order_user_phone," +
                            "order_recive_addr1,order_recive_addr2,order_recive_addr3,order_type2,order_total_price,o.delivery_price," +
                            "discount_price,wr_subject,company_number,mb_name,store_hp,order_shop_msg,order_driver_msg,store_addr1,store_addr2 " +
                            "from order_form as o left join store_detail as d on o.wr_id = d.wr_id " +
                            "left join g5_write_main as w on w.wr_id = d.wr_id left join g5_member as e on e.mb_id = w.mb_id " +
                            "where order_id = " + _order_id + " order by  o.order_date desc , o.order_state, o.delivery_state";
                        mCommand = new MySqlCommand(sql, mConnection);
                        mDataReader = mCommand.ExecuteReader();

                        if (mDataReader.HasRows)
                        {
                            while (mDataReader.Read())
                            {
                                orderNumber = mDataReader["order_number"].ToString();
                                orderDate = mDataReader["order_date"].ToString();
                                storeName = mDataReader["wr_subject"].ToString();
                                storeNumber = mDataReader["company_number"].ToString();
                                deliAddr = mDataReader["order_recive_addr1"].ToString() + " " + mDataReader["order_recive_addr2"].ToString() + " " + mDataReader["order_recive_addr3"].ToString();
                                storeCeo = mDataReader["mb_name"].ToString();
                                storeTel = mDataReader["store_hp"].ToString();
                                orderMsg = mDataReader["order_shop_msg"].ToString();
                                deliMsg = mDataReader["order_driver_msg"].ToString();
                                deliTel = mDataReader["order_user_phone"].ToString();
                                storeAddr = mDataReader["store_addr1"].ToString() + " " + mDataReader["store_addr2"].ToString();
                                payType = mDataReader["order_type2"].ToString();
                                menu_name = mDataReader["order_menu"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                                menu_count = mDataReader["order_count"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                                menu_price = mDataReader["order_price"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                                dicountPrice = Int32.Parse(mDataReader["discount_price"].ToString());
                                deliveryPrice = Int32.Parse(mDataReader["delivery_price"].ToString());
                                totalPrice = Int32.Parse(mDataReader["order_total_price"].ToString());

                                if (!String.IsNullOrEmpty(mDataReader["order_option"].ToString().Trim()))
                                {
                                    string[] menu_options = mDataReader["order_option"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                                    string[] menu_options_price = mDataReader["order_option_price"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                                    if (menu_options.Length > 0)
                                    {
                                        for (int i = 0; i < menu_name.Length; i++)
                                        {
                                            menu.Add(menu_name[i]);
                                            menu.Add(String.Format("{0:###,###,###,###}", Int32.Parse(menu_price[i])) + "         " + menu_count[i] + "         " + String.Format("{0:###,###,###,###}", (Int32.Parse(menu_price[i]) * Int32.Parse(menu_count[i]))));

                                            if (!String.IsNullOrEmpty(menu_options[i]))
                                            {
                                                string op = "";
                                                string[] menu_option_detail = menu_options[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                                string[] menu_options_prices = menu_options_price[i].Split(new string[] { "||" }, StringSplitOptions.None);
                                                for (int j = 0; j < menu_option_detail.Length; j++)
                                                {
                                                    op = "└" + menu_option_detail[j];
                                                    if (menu_options_prices[j] != "0")
                                                    {
                                                        menu.Add(op + "      " + String.Format("{0:###,###,###,###}", menu_options_prices[j]));
                                                    }
                                                    else
                                                    {
                                                        menu.Add(op + "      " + menu_options_prices[j]);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    for (int i = 0; i < menu_name.Length; i++)
                                    {
                                        menu.Add(menu_name[i]);
                                        menu.Add(String.Format("{0:###,###,###,###}", menu_price[i]) + "         " + menu_count[i] + "         " + String.Format("{0:###,###,###,###}", (Int32.Parse(menu_price[i]) * Int32.Parse(menu_count[i]))));

                                    }
                                }
                            }
                        }
                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(er.Message);
                    }

                    storeNumber = storeNumber.Replace("-", "");

                    thermalPrinting(storeName, storeNumber, storeAddr, storeCeo, storeTel, orderDate, menu, orderMsg, totalPrice, dicountPrice, deliveryPrice, deliAddr, deliTel, deliMsg, payType);
                }
                else
                {
                    MessageBox.Show("프린트연결을 확인해주세요.");
                }
            }
        }


        private void thermalPrinting(string storeName, string storeNum, string storeAddr, string storeCeo, string storeTel, string orderDate, ArrayList menu, string storeMsg, int totalPrice, int discountPrice, int deliveryPrice, string deliAddr, string deliTel, string deliMsg, string payType)
        {

            //////
            int allPrice = totalPrice + deliveryPrice - discountPrice;


            byte[] cr = new byte[1];
            cr[0] = 0x0A;
            byte[] scutting = new byte[3];
            scutting[0] = 0x1D;
            scutting[1] = 0x56;
            scutting[2] = 0x01;
            byte[] fcutting = new byte[3];
            fcutting[0] = 0x1D;
            fcutting[1] = 0x56;
            fcutting[2] = 0x00;
            byte[] korean = new byte[3];
            korean[0] = 0x1A;
            korean[1] = 0x78;
            korean[2] = 0x00;
            byte[] feed = new byte[3];
            feed[0] = 0x1b;
            feed[1] = 0x4a;
            feed[2] = 0xc8;
            byte[] reset = new byte[2];
            reset[0] = 0x1b;
            reset[1] = 0x40;
            byte[] koreanfont = new byte[3];
            koreanfont[0] = 0x1B;
            koreanfont[1] = 0x4D;
            koreanfont[2] = 0x00;
            byte[] align = new byte[3];
            align[0] = 0x1B;
            align[1] = 0x61;
            align[2] = 0x01;
            byte[] fontsize = new byte[3];
            fontsize[0] = 0x1D;
            fontsize[1] = 0x21;
            fontsize[2] = 0x01;
            byte[] koreanfontsize = new byte[3];
            koreanfontsize[0] = 0x1c;
            koreanfontsize[1] = 0x57;
            koreanfontsize[2] = 0x01;
            byte[] margin = new byte[4];
            margin[0] = 0x1d;
            margin[1] = 0x4c;
            margin[2] = 0x08;
            margin[3] = 0x00;

            bool returns = BaedalItemList.m_SerialPort.Send_Data(reset);
            if (returns == false)
            {
                MessageBox.Show("프린트 연결 상태를 확인해주세요!");
            }
            else
            {
                //BaedalItemList.m_SerialPort.Send_Data(reset);
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("청주배프 영수증 - 고객용"));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);

                BaedalItemList.m_SerialPort.Send_Data(reset);
                fontsize[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[매장명] " + storeName));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[사업자] " + storeNum));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[주  소] " + storeAddr));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[대표자] " + storeCeo));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[연락처] " + storeTel));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[매출일] " + orderDate));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[영수증] " + DateTime.Now.ToString("yyyy-mm-dd HH:mm:ss")));
                BaedalItemList.m_SerialPort.Send_Data(cr);

                //koreanfontsize[2] = 0x01;
                align[2] = 0x01;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("========================================="));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("상품명"));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("     단가       수량       금액     "));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("-----------------------------------------"));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                align[2] = 0x01;
                BaedalItemList.m_SerialPort.Send_Data(align);
                //메뉴 출력
                int mi = 0;
                foreach (string menus in menu)
                {
                    int num = 0;
                    bool res = int.TryParse(menus.Substring(0, 1), out num);
                    if (mi != 0 && menu.Count != (mi + 1) && !menus.Contains("└") && !res)
                    {
                        BaedalItemList.m_SerialPort.Send_Data(cr);
                    }
                    BaedalItemList.m_SerialPort.Send_Data(str2bytes(menus));
                    BaedalItemList.m_SerialPort.Send_Data(cr);
                    mi++;
                }

                //BaedalItemList.m_SerialPort.Send_Data(str2bytes(menu));
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("-----------------------------------------"));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(reset);
                fontsize[2] = 0x01;
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("주문금액"));
                align[2] = 0x02;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(String.Format("{0:###,###,###,###}", totalPrice), "주문금액".Length, 32)));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("배 달 팁"));
                align[2] = 0x02;
                BaedalItemList.m_SerialPort.Send_Data(align);
                if (deliveryPrice == 0)
                {
                    BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(deliveryPrice.ToString(), "배 달 팁".Length, 32)));
                }
                else
                {
                    BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(String.Format("{0:###,###,###,###}", deliveryPrice), "배 달 팁".Length, 32)));
                }
                BaedalItemList.m_SerialPort.Send_Data(cr);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("할인금액"));
                align[2] = 0x02;
                BaedalItemList.m_SerialPort.Send_Data(align);
                if (discountPrice == 0)
                {
                    BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(discountPrice.ToString(), "할인금액".Length, 32)));
                }
                else
                {
                    BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(String.Format("{0:###,###,###,###}", discountPrice), "할인금액".Length, 32)));
                }
                BaedalItemList.m_SerialPort.Send_Data(cr);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("결제금액"));
                align[2] = 0x02;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes(padLeft(String.Format("{0:###,###,###,###}", allPrice), "결제금액".Length, 32)));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                fontsize[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                align[2] = 0x01;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("-----------------------------------------"));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                fontsize[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                align[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("결제방식" + padLeft(payType, "결제방식".Length, 26)));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                align[2] = 0x01;
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("-----------------------------------------"));
                fontsize[2] = 0x00;
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("* 청주배프는 수수료없는 착한 어플입니다."));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("[재발행] " + DateTime.Now.ToString("yyyy-mm-dd hh:mm:ss")));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(feed);
                BaedalItemList.m_SerialPort.Send_Data(fcutting);

                BaedalItemList.m_SerialPort.ClosePort();
            }
        }

        static public byte[] str2bytes(string byteData)
        {
            System.Text.ASCIIEncoding asencoding = new System.Text.ASCIIEncoding();
            return Encoding.Default.GetBytes(byteData);
        }

        static public string padLeft(string str, int minLen, int fulllen)
        {
            string lPad = "";
            int strlen = str.Length;
            int callen = fulllen - strlen;

            for (int i = 0; i < callen; i++)
            {
                lPad += " ";
            }

            return lPad + str;
        }
    }
}
