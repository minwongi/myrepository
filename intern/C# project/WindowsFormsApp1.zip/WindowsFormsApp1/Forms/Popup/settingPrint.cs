﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;
using System.IO.Ports;
using System.Management;

namespace BaedalFriend.Forms.Popup
{
    public partial class settingPrint : Form
    {
        public settingPrint()
        {
            InitializeComponent();
        }

        private void settingPrint_Load(object sender, EventArgs e)
        {
            //포트 목록 불러오기
            //SerialPort port = new SerialPort();
            /*string[] portNames = SerialPort.GetPortNames();
            var portSet = portNames.Select(a => a).Distinct();*/
            var i = 0;

            var ManagementScope = new ManagementScope(ManagementPath.DefaultPath);
            ManagementScope.Connect();

            SelectQuery select = new SelectQuery();
            select.QueryString = "SELECT * FROM Win32_Printer";

            ManagementObjectSearcher objectSearcher = new ManagementObjectSearcher(ManagementScope, select);
            ManagementObjectCollection collection = objectSearcher.Get();

            foreach(ManagementObject Item in collection)
            {
                string ports = Item.Properties["Caption"].Value + " (PORT : " + Item.Properties["PortName"].Value + ")";
                this.seralPortList.Items.Add(ports);
                this.printerPort.Items.Add(Item.Properties["PortName"].Value.ToString().Replace(':', ' ').Trim());
                if (!String.IsNullOrEmpty(Properties.Settings.Default.PortNum) && Item.Properties["PortName"].Value.ToString().Replace(':', ' ').Trim() == Properties.Settings.Default.PortNum)
                {
                    seralPortList.SelectedIndex = i;
                }
                i++;
            }

            /*
            foreach (string ports in portSet)
            {
                this.seralPortList.Items.Add(ports);
                if (!String.IsNullOrEmpty(Properties.Settings.Default.PortNum) && ports == Properties.Settings.Default.PortNum)
                {
                    seralPortList.SelectedIndex = i;    
                }
                i++;W
            }
            */
            
            if (String.IsNullOrEmpty(Properties.Settings.Default.PortNum))
            {
                seralPortList.SelectedIndex = 0;
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            printerPort.SelectedIndex = seralPortList.SelectedIndex;
            string port = printerPort.SelectedItem.ToString();

            try
            {
                Console.WriteLine("select Port : " + seralPortList.SelectedItem.ToString() + "// Properties : " + Properties.Settings.Default.PortNum);
                //if (BaedalItemList.m_SerialPort.OpenPort(seralPortList.SelectedItem.ToString(), 9600))
                //{
                Console.WriteLine("select In");
                BaedalItemList.m_SerialPort.OpenPort(port, 19200);
                thermalPrinting();

                Properties.Settings.Default.PortNum = port;
                Properties.Settings.Default.Save();

                BaedalItemList.m_SerialPort.ClosePort();
                //}
                //else
                //{
                //    MessageBox.Show("연결할 수 없습니다.");
                //}
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void thermalPrinting()
        {
            //try
            //{
            byte[] cr = new byte[1];
            cr[0] = 0x0A;
            byte[] cutting = new byte[3];
            cutting[0] = 0x1D;
            cutting[1] = 0x56;
            cutting[2] = 0x01;
            byte[] korean = new byte[3];
            korean[0] = 0x1A;
            korean[1] = 0x78;
            korean[2] = 0x00;
            byte[] feed = new byte[3];
            feed[0] = 0x1b;
            feed[1] = 0x4a;
            feed[2] = 0xc8;
            byte[] reset = new byte[2];
            reset[0] = 0x1b;
            reset[1] = 0x40;
            byte[] koreanfont = new byte[3];
            koreanfont[0] = 0x1B;
            koreanfont[1] = 0x4D;
            koreanfont[2] = 0x00;
            byte[] align = new byte[3];
            align[0] = 0x1B;
            align[1] = 0x61;
            align[2] = 0x01;
            byte[] fontsize = new byte[3];
            fontsize[0] = 0x1d;
            fontsize[1] = 0x21;
            fontsize[2] = 0x01;
            byte[] koreanfontsize = new byte[3];
            koreanfontsize[0] = 0x1c;
            koreanfontsize[1] = 0x57;
            koreanfontsize[2] = 0x01;
            byte[] margin = new byte[4];
            margin[0] = 0x1d;
            margin[1] = 0x4c;
            margin[2] = 0x08;
            margin[3] = 0x00;

            bool results = BaedalItemList.m_SerialPort.Send_Data(reset);
            if (results == false)
            {
                MessageBox.Show("프린트 연결을 할 수 없습니다.");
            }
            else
            { 
                BaedalItemList.m_SerialPort.Send_Data(fontsize);
                BaedalItemList.m_SerialPort.Send_Data(align);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(str2bytes("프린트 테스트 입니다.\r\n정상 연결 되었습니다."));
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(cr);
                BaedalItemList.m_SerialPort.Send_Data(feed);
                BaedalItemList.m_SerialPort.Send_Data(cutting);
            }
            //}
            /*catch(Exception e)
            {
                MessageBox.Show("Printer 연결에 실패 하였습니다.");
            }*/
        }

        static public byte[] str2bytes(string byteData)
        {
            System.Text.ASCIIEncoding asencoding = new System.Text.ASCIIEncoding();
            return Encoding.Default.GetBytes(byteData);
        }
    }
}
