﻿namespace BaedalFriend.Forms.Popup
{
    partial class popup_order_confirm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(popup_order_confirm));
            this.confirm_btn = new System.Windows.Forms.Button();
            this.deliveryTime = new System.Windows.Forms.ComboBox();
            this.deli_label = new System.Windows.Forms.Label();
            this.deli_time_text = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // confirm_btn
            // 
            this.confirm_btn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.confirm_btn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.confirm_btn.Location = new System.Drawing.Point(125, 120);
            this.confirm_btn.Name = "confirm_btn";
            this.confirm_btn.Size = new System.Drawing.Size(125, 40);
            this.confirm_btn.TabIndex = 2;
            this.confirm_btn.Text = "주문접수";
            this.confirm_btn.UseVisualStyleBackColor = true;
            this.confirm_btn.Click += new System.EventHandler(this.confirm_btn_Click);
            // 
            // deliveryTime
            // 
            this.deliveryTime.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.deliveryTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.deliveryTime.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.deliveryTime.FormattingEnabled = true;
            this.deliveryTime.Location = new System.Drawing.Point(15, 51);
            this.deliveryTime.Margin = new System.Windows.Forms.Padding(10);
            this.deliveryTime.Name = "deliveryTime";
            this.deliveryTime.Size = new System.Drawing.Size(347, 24);
            this.deliveryTime.TabIndex = 1;
            this.deliveryTime.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // deli_label
            // 
            this.deli_label.AutoSize = true;
            this.deli_label.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.deli_label.Location = new System.Drawing.Point(14, 20);
            this.deli_label.Name = "deli_label";
            this.deli_label.Size = new System.Drawing.Size(104, 16);
            this.deli_label.TabIndex = 2;
            this.deli_label.Text = "배달예상시간";
            // 
            // deli_time_text
            // 
            this.deli_time_text.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.deli_time_text.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.deli_time_text.Font = new System.Drawing.Font("굴림", 12F);
            this.deli_time_text.Location = new System.Drawing.Point(15, 81);
            this.deli_time_text.Name = "deli_time_text";
            this.deli_time_text.Size = new System.Drawing.Size(347, 26);
            this.deli_time_text.TabIndex = 3;
            // 
            // popup_order_confirm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 179);
            this.Controls.Add(this.deli_time_text);
            this.Controls.Add(this.deli_label);
            this.Controls.Add(this.deliveryTime);
            this.Controls.Add(this.confirm_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "popup_order_confirm";
            this.Text = "주문접수";
            this.Load += new System.EventHandler(this.popup_order_confirm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button confirm_btn;
        private System.Windows.Forms.ComboBox deliveryTime;
        private System.Windows.Forms.Label deli_label;
        private System.Windows.Forms.TextBox deli_time_text;
    }
}