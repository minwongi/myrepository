﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using MySql.Data.MySqlClient;
using BaedalFriend.Model;
using System.Threading;
using System.IO;
using System.IO.Ports;
using BaedalFriend;

namespace BaedalFriend.Forms.Popup
{
    public partial class popup_alarm : Form
    {
        /*public static String Server = "Server=211.110.229.204; Uid=flug; Database=giveyou; Pwd=flug0258; Port=3306";
        private MySqlConnection mConnection;
        private MySqlCommand mCommand;
        private MySqlDataReader mDataReader;*/
        int orderTimer = 10; //10분

        public string _strMsg { get; set; }
        public string _CasCnt { get; set; }

        public popup_alarm()
        {
            InitializeComponent();
            Regstry reg = new Regstry();
            reg.setBrowser();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //접수
            BaedalItemList.popConfirm = new popup_order_confirm(this, _strMsg);
            BaedalItemList.popConfirm.ShowDialog();
            //this.Close();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            try
            { 
                SoundPlayer player = new SoundPlayer(Properties.Resources.noti);
                player.Play();
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " not playing");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            /*Form order_cancel = new popup_order_cancel
            {
                _order_id = _strMsg
            };*/
            BaedalItemList.popCancel = new popup_order_cancel(this, _strMsg);
            BaedalItemList.popCancel.ShowDialog();
            //order_cancel.ShowDialog();

        }

        public void timerClose(object sender, EventArgs e)
        {
            //취소는 웹서버에서 자동 진행
            this.btn_ok.Text = "주문접수 - " + (orderTimer--) + "분 남음";
            if (orderTimer == 0)
            {
                this.Close();
            }
            else
            {
                try
                {
                    SoundPlayer player = new SoundPlayer(Properties.Resources.noti);
                    player.Play();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, " not playing");
                }
            }
        }

        public void PrinterCheck(object sender, EventArgs e)
        {

        }

        private void popup_alarm_Load(object sender, EventArgs e)
        {

            /*if (BaedalItemList.m_SerialPort.OpenPort(Properties.Settings.Default.PortNum, 19200))
            {
                MessageBox.Show("프린트 연결이 완료 되었습니다.");
            }
            else
            {
                MessageBox.Show("연결 실패");
            }*/

            //thermalPrinting("9393","청주배프","ㅅㄷㄴㅅ","1234","5678","3000","33","2020","1515");

            string url = "https://flugbf.kr/page/shop/store_order_detail_application.php?order_id="+_strMsg;

            this.orderWebview.Navigate(url);

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000 * 60; //1분
            timer.Tick += new EventHandler(timerClose);
            timer.Start();

            //주문상태체크해야할듯....

            /*mConnection = new MySqlConnection(Server); // DB접속

            try
            {
                mConnection.Open();

                string sql = "select * from order_form as o left join g5_write_main as m on o.wr_id = m.wr_id left join store_detail as d on m.wr_id = d.wr_id left join g5_member as e on e.mb_id = o.mb_id where order_id = " + _strMsg;
                //MessageBox.Show(sql);
                mCommand = new MySqlCommand(sql, mConnection);
                mDataReader = mCommand.ExecuteReader();
                if (mDataReader.Read())
                {

                    string menu_name = mDataReader["order_menu"].ToString();
                    string menu_price = mDataReader["order_price"].ToString();
                    string menu_count = mDataReader["order_count"].ToString();
                    string option_name= mDataReader["order_option"].ToString();
                    string option_price = mDataReader["order_option_price"].ToString();

                    string[] menus = menu_name.Split(',');
                    string[] menu_prices = menu_name.Split(',');
                    string[] menu_counts = menu_count.Split(',');

                    string[] options = null;
                    string[] option_prices = null;
                    
                    if (!String.IsNullOrEmpty(option_name)) {
                        options = option_name.Split(new String[] { "||" }, StringSplitOptions.None);
                        option_prices = option_price.Split(new String[] { "||" }, StringSplitOptions.None);
                    }

                    int total = 0;
                    int option_total = 0;
                    string menu_str = "";
                    for (int i = 0; i < menus.Length; i++)
                    {
                        menu_str += menus[i];
                        if (!String.IsNullOrEmpty(option_name))
                        {
                            if (!String.IsNullOrEmpty(options[i]))
                            {
                                string[] options_detail = options[i].Split(',');
                                string[] option_price_detail = options[i].Split(',');
                                for(int j = 0; j < options_detail.Length; j++)
                                {
                                    
                                }
                            }
                        }
                        
                        total += Int32.Parse(menu_prices[i]);
                    }

                    string od_number = mDataReader["order_number"].ToString();
                    string od_date = mDataReader["order_date"].ToString();
                    string od_type = mDataReader["order_type2"].ToString();
                    string od_name = mDataReader["mb_name"].ToString();
                    string od_addr1 = mDataReader["order_recive_addr1"].ToString();
                    string od_addr2 = mDataReader["order_recive_addr2"].ToString();
                    string od_addr3 = mDataReader["order_recive_addr3"].ToString();
                    string od_msg = mDataReader["order_shop_msg"].ToString();
                    string od_drive_msg = mDataReader["order_driver_msg"].ToString();

                    MessageBox.Show(od_number + "//" + od_date + "//" + od_type + "//" + od_addr1 + "//" + od_addr2 + "//" + od_addr3 + "//" + od_msg + "//" + od_drive_msg+"//"+total);
                }
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /*
        private void thermalPrinting(string CarNum, string Company, string Material, string CAS1stVal, string CAS2stVal, string CalVal, string div, string CAS1stTime, string CAS2stTime)
        {

            //////

            string strMaterial = String.Empty;
            string divCompany = String.Empty;
            if (div == "입고")
            {
                strMaterial = "석회석 - " + Material;
                divCompany = "거 래 처 : " + Company;
            }
            else
            {
                strMaterial = "탄 산 칼 슘";
                divCompany = "도 착 지 : " + Company;
            }

            byte[] cr = new byte[1];
            cr[0] = 0x0A;
            byte[] cutting = new byte[3];
            cutting[0] = 0x1D;
            cutting[1] = 0x56;
            cutting[2] = 0x01;
            byte[] korean = new byte[3];
            korean[0] = 0x1A;
            korean[1] = 0x78;
            korean[2] = 0x00;
            byte[] feed = new byte[3];
            feed[0] = 0x1b;
            feed[1] = 0x4a;
            feed[2] = 0xc8;
            byte[] reset = new byte[2];
            reset[0] = 0x1b;
            reset[1] = 0x40;
            byte[] koreanfont = new byte[3];
            koreanfont[0] = 0x1B;
            koreanfont[1] = 0x4D;
            koreanfont[2] = 0x00;
            byte[] align = new byte[3];
            align[0] = 0x1B;
            align[1] = 0x61;
            align[2] = 0x01;
            byte[] fontsize = new byte[3];
            fontsize[0] = 0x1d;
            fontsize[1] = 0x21;
            fontsize[2] = 0x01;
            byte[] koreanfontsize = new byte[3];
            koreanfontsize[0] = 0x1c;
            koreanfontsize[1] = 0x57;
            koreanfontsize[2] = 0x01;
            byte[] margin = new byte[4];
            margin[0] = 0x1d;
            margin[1] = 0x4c;
            margin[2] = 0x08;
            margin[3] = 0x00;

            //MessageBox.Show("준비중입니다.");
            BaedalItemList.m_SerialPort.Send_Data(reset);
            //m_SerialPort.Send_Data(korean);
            //m_SerialPort.Send_Data(koreanfont);
            BaedalItemList.m_SerialPort.Send_Data(koreanfontsize);
            BaedalItemList.m_SerialPort.Send_Data(align);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(margin);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("계 량 증 명 서"));
            koreanfontsize[2] = 0x00;
            BaedalItemList.m_SerialPort.Send_Data(koreanfontsize);
            BaedalItemList.m_SerialPort.Send_Data(fontsize);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("=========================="));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            align[2] = 0x00;
            BaedalItemList.m_SerialPort.Send_Data(align);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("----------------------------------"));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("일    자: " + DateTime.Now.ToString("yyyy-MM-dd") + " [" + _CasCnt + "]"));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("차량번호: " + CarNum));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes(divCompany));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("품    명: " + strMaterial));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("입차중량: " + CAS1stTime + " / " + CAS1stVal + " kg "));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("출차중량: " + CAS2stTime + " / " + CAS2stVal + " kg "));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("실 중 량: " + CalVal + " kg "));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("구    분: " + div));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("----------------------------------"));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            align[2] = 0x01;
            BaedalItemList.m_SerialPort.Send_Data(align);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("Tel : 033)374-9910"));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(str2bytes("(주)충무화학 영월"));
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(cr);
            BaedalItemList.m_SerialPort.Send_Data(feed);
            BaedalItemList.m_SerialPort.Send_Data(cutting);
        }

        static public byte[] str2bytes(string byteData)
        {
            System.Text.ASCIIEncoding asencoding = new System.Text.ASCIIEncoding();
            return Encoding.Default.GetBytes(byteData);
        }*/

    }
}
