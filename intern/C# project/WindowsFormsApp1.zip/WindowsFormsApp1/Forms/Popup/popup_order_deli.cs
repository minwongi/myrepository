﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;

namespace BaedalFriend.Forms.Popup
{
    public partial class popup_order_deli : Form
    {
        public string _order_id { get; set; }

        public popup_order_deli()
        {
            InitializeComponent();
            Regstry reg = new Regstry();
            reg.setBrowser();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deli_Btn_Click(object sender, EventArgs e)
        {
            //시간 전달 후 서버에서 푸시 알림 보내기
            if (!String.IsNullOrEmpty(_order_id))
            {
                Boolean reqState = false;

                string url = "https://flugbf.kr/page/application/store_order_fin.php?order_id=" + _order_id;

                Console.WriteLine(url);
                UrlRequest req = new UrlRequest();
                reqState = req.request(url);
                if (reqState)
                {
                    MessageBox.Show("주문 완료 처리 되었습니다.", "확인");

                    this.Close();
                    BaedalItemList.orderfrm.LoadOrder();
                }
            }
            else
            {
                MessageBox.Show("주문정보를 가져올 수 없습니다.");
            }
        }

        private void popup_order_deli_Load(object sender, EventArgs e)
        {
            string url = "https://flugbf.kr/page/shop/store_order_detail_application.php?order_id=" + _order_id;

            this.orderWebview.Navigate(url);
        }
    }
}
