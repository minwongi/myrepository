﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;
namespace BaedalFriend.Forms.Popup
{
    public partial class popup_order_cancel : Form
    {
        //부모폼
        public popup_alarm parent = null;
        public popup_cancel parent2 = null;
        public string _order_id { get; set; }

        public popup_order_cancel()
        {
            InitializeComponent();
        }

        public popup_order_cancel(popup_alarm parent, string order_id)
        {

            InitializeComponent();

            this.parent = parent;
            _order_id = order_id;

        }

        public popup_order_cancel(popup_cancel parent, string order_id)
        {

            InitializeComponent();

            this.parent2 = parent;
            _order_id = order_id;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("해당 주문건을 취소하시겠습니까?", "주문취소", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Boolean reqState = false;
                string cancel_con = cancel_content.Text.ToString();

                string url = "https://flugbf.kr/page/application/store_order_cancel.php?order_id=" + _order_id + "&cancel_con=" + cancel_con;

                Console.WriteLine(url);
                UrlRequest req = new UrlRequest();
                reqState = req.request(url);
                if (reqState)
                {
                    MessageBox.Show("주문취소성공", "확인");

                    this.Close();
                    if (parent != null)
                    {
                        BaedalItemList.orderfrm.LoadOrder();
                        parent.Hide();
                    }
                    if(parent2 != null)
                    {
                        BaedalItemList.orderfrm.LoadOrder();
                        parent2.Hide();
                    }

                }
            } else
            {
                this.cancel_content.Text = "";
                this.Close();
            }
            //this.Close();
        }

        private void popup_order_cancel_Load(object sender, EventArgs e)
        {
            //this.orderId.Text = _order_id;
        }
    }
}
