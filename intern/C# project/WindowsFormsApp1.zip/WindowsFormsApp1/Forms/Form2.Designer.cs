﻿namespace BaedalFriend
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.logout_btn = new System.Windows.Forms.Button();
            this.order_btn = new System.Windows.Forms.Button();
            this.store_btn = new System.Windows.Forms.Button();
            this.notiIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.TrayMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuStrip_full = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.viewContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.print_set = new System.Windows.Forms.Button();
            this.account_btn = new System.Windows.Forms.Button();
            this.maintitle = new System.Windows.Forms.Label();
            this.close_btn = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TrayMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // logout_btn
            // 
            this.logout_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logout_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(188)))), ((int)(((byte)(37)))));
            this.logout_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout_btn.FlatAppearance.BorderSize = 0;
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.ForeColor = System.Drawing.Color.White;
            this.logout_btn.Location = new System.Drawing.Point(12, 612);
            this.logout_btn.Margin = new System.Windows.Forms.Padding(0);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(98, 38);
            this.logout_btn.TabIndex = 5;
            this.logout_btn.Text = "로그아웃";
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // order_btn
            // 
            this.order_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.order_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("order_btn.BackgroundImage")));
            this.order_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.order_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.order_btn.FlatAppearance.BorderSize = 0;
            this.order_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.order_btn.ForeColor = System.Drawing.Color.Black;
            this.order_btn.Location = new System.Drawing.Point(12, 10);
            this.order_btn.Margin = new System.Windows.Forms.Padding(10);
            this.order_btn.Name = "order_btn";
            this.order_btn.Padding = new System.Windows.Forms.Padding(50);
            this.order_btn.Size = new System.Drawing.Size(98, 98);
            this.order_btn.TabIndex = 1;
            this.order_btn.UseVisualStyleBackColor = false;
            this.order_btn.Click += new System.EventHandler(this.orderBtn_Click);
            // 
            // store_btn
            // 
            this.store_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.store_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("store_btn.BackgroundImage")));
            this.store_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.store_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.store_btn.FlatAppearance.BorderSize = 0;
            this.store_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.store_btn.ForeColor = System.Drawing.Color.Black;
            this.store_btn.Location = new System.Drawing.Point(12, 121);
            this.store_btn.Name = "store_btn";
            this.store_btn.Size = new System.Drawing.Size(98, 98);
            this.store_btn.TabIndex = 2;
            this.store_btn.UseVisualStyleBackColor = false;
            this.store_btn.Click += new System.EventHandler(this.storeBtn_Click);
            // 
            // notiIcon
            // 
            this.notiIcon.ContextMenuStrip = this.TrayMenu;
            this.notiIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notiIcon.Icon")));
            this.notiIcon.Text = "청주배프";
            this.notiIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notiIcon_MouseDoubleClick);
            // 
            // TrayMenu
            // 
            this.TrayMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuStrip_full,
            this.MenuStrip_exit});
            this.TrayMenu.Name = "contextMenuStrip1";
            this.TrayMenu.Size = new System.Drawing.Size(147, 48);
            // 
            // MenuStrip_full
            // 
            this.MenuStrip_full.Name = "MenuStrip_full";
            this.MenuStrip_full.Size = new System.Drawing.Size(146, 22);
            this.MenuStrip_full.Tag = "MAXIMUM";
            this.MenuStrip_full.Text = "최대화";
            this.MenuStrip_full.Click += new System.EventHandler(this.MenuStrip_full_Click);
            // 
            // MenuStrip_exit
            // 
            this.MenuStrip_exit.Name = "MenuStrip_exit";
            this.MenuStrip_exit.Size = new System.Drawing.Size(146, 22);
            this.MenuStrip_exit.Tag = "CLOSE";
            this.MenuStrip_exit.Text = "프로그램종료";
            this.MenuStrip_exit.Click += new System.EventHandler(this.MenuStrip_exit_Click);
            // 
            // viewContainer
            // 
            this.viewContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.viewContainer.AutoSize = true;
            this.viewContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.viewContainer.Location = new System.Drawing.Point(123, 35);
            this.viewContainer.Margin = new System.Windows.Forms.Padding(0);
            this.viewContainer.Name = "viewContainer";
            this.viewContainer.Size = new System.Drawing.Size(986, 642);
            this.viewContainer.TabIndex = 6;
            // 
            // print_set
            // 
            this.print_set.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.print_set.BackColor = System.Drawing.Color.Gray;
            this.print_set.Cursor = System.Windows.Forms.Cursors.Hand;
            this.print_set.FlatAppearance.BorderSize = 0;
            this.print_set.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.print_set.ForeColor = System.Drawing.Color.White;
            this.print_set.Location = new System.Drawing.Point(12, 574);
            this.print_set.Margin = new System.Windows.Forms.Padding(0);
            this.print_set.Name = "print_set";
            this.print_set.Size = new System.Drawing.Size(98, 38);
            this.print_set.TabIndex = 4;
            this.print_set.Text = "프린트설정";
            this.print_set.UseVisualStyleBackColor = false;
            this.print_set.Click += new System.EventHandler(this.print_set_Click);
            // 
            // account_btn
            // 
            this.account_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.account_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("account_btn.BackgroundImage")));
            this.account_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.account_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.account_btn.FlatAppearance.BorderSize = 0;
            this.account_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.account_btn.ForeColor = System.Drawing.Color.Black;
            this.account_btn.Location = new System.Drawing.Point(12, 232);
            this.account_btn.Name = "account_btn";
            this.account_btn.Size = new System.Drawing.Size(98, 98);
            this.account_btn.TabIndex = 3;
            this.account_btn.UseVisualStyleBackColor = false;
            this.account_btn.Click += new System.EventHandler(this.accountBtn_Click);
            // 
            // maintitle
            // 
            this.maintitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.maintitle.AutoSize = true;
            this.maintitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.maintitle.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.maintitle.ForeColor = System.Drawing.Color.White;
            this.maintitle.Location = new System.Drawing.Point(32, 3);
            this.maintitle.Name = "maintitle";
            this.maintitle.Size = new System.Drawing.Size(82, 17);
            this.maintitle.TabIndex = 10;
            this.maintitle.Text = "배프 상점용";
            this.maintitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // close_btn
            // 
            this.close_btn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.close_btn.AutoSize = true;
            this.close_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.close_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close_btn.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Bold);
            this.close_btn.ForeColor = System.Drawing.Color.White;
            this.close_btn.Location = new System.Drawing.Point(1089, 3);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(20, 19);
            this.close_btn.TabIndex = 6;
            this.close_btn.Text = "X";
            this.close_btn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.maintitle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1121, 25);
            this.panel1.TabIndex = 11;
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.White;
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(188)))), ((int)(((byte)(37)))));
            this.linkLabel1.Location = new System.Drawing.Point(953, 8);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(125, 12);
            this.linkLabel1.TabIndex = 12;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "원격연결파일다운로드";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(5, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.order_btn);
            this.panel2.Controls.Add(this.store_btn);
            this.panel2.Controls.Add(this.account_btn);
            this.panel2.Controls.Add(this.print_set);
            this.panel2.Controls.Add(this.logout_btn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(110, 664);
            this.panel2.TabIndex = 12;
            // 
            // Form2
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1121, 689);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.viewContainer);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "배프상점용";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.TrayMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Button order_btn;
        private System.Windows.Forms.Button store_btn;
        private System.Windows.Forms.NotifyIcon notiIcon;
        private System.Windows.Forms.ContextMenuStrip TrayMenu;
        private System.Windows.Forms.FlowLayoutPanel viewContainer;
        private System.Windows.Forms.Button print_set;
        private System.Windows.Forms.Button account_btn;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_exit;
        private System.Windows.Forms.ToolStripMenuItem MenuStrip_full;
        private System.Windows.Forms.Label maintitle;
        private System.Windows.Forms.Label close_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}