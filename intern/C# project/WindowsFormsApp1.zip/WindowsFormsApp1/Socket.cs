﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using BaedalFriend;
using BaedalFriend.Model;

namespace BaedalFriend.socket.client
{
    class Client : SocketAsyncEventArgs
    {
        //private Socket socket;
        private StringBuilder sb = new StringBuilder();
        public string _id { get; set; }

        public Client(EndPoint pep,string mb_id)
        {
            RemoteEndPoint = pep;

            base.Completed -= Connected_Completed;
            base.Completed += Connected_Completed;

            this._id = mb_id;
        }

        private void Connected_Completed(object sender, SocketAsyncEventArgs e)
        {
            base.Completed -= Connected_Completed;
            BaedalItemList.socket = e.ConnectSocket;

            if (BaedalItemList.socket != null)
            {
                base.UserToken = BaedalItemList.socket;
                base.SetBuffer(new byte[1024], 0, 1024);

                base.Completed += Client_Completed;
                BaedalItemList.socket.ReceiveAsync(this);
                Send(BaedalItemList.socket, "M01 "+_id);
            }
            else
            {
                Console.WriteLine($"Server Not Found");
            }
        }

        private void alarm(string msg)
        {
            //string msg = sb.ToString();
            BaedalItemList.frmMain.alarm(msg);
        }

        private void Client_Completed(object sender, SocketAsyncEventArgs e)
        {
            if (BaedalItemList.socket.Connected && base.BytesTransferred > 0)
            {
                byte[] data = e.Buffer;
                string msg = Encoding.UTF8.GetString(data);
                base.SetBuffer(new byte[1024], 0, 1024);
                sb.Append(msg.Trim('\0'));

                BaedalItemList.frmMain.alarm(sb.ToString());

                if (sb.Length >= 3)
                {
                    if (sb[0] == 'M')
                    {
                        if (sb[1] == '0')
                        {
                            if (sb[2] == '0')
                            {
                                Send(BaedalItemList.socket,"M00JSON");
                                Console.Write("Server Connected by JSON\r\n>");
                            }
                        }
                    }
                    else
                    {
                        msg = sb.ToString();
                        Console.Write(msg);
                    }
                }
                else
                {
                    msg = sb.ToString();
                    Console.Write(msg);
                }

                sb.Clear();
                BaedalItemList.socket.ReceiveAsync(this);
            }
            else
            {
                var remoteAddr = (IPEndPoint)BaedalItemList.socket.RemoteEndPoint;
                Console.WriteLine($"Disconnected : (From: {remoteAddr.Address.ToString()}:{remoteAddr.Port}, Connection time: {DateTime.Now})");
            }
        }

        private byte[] setHeadData(byte[] msg)
        {
            byte[] head = new byte[4 + msg.Length];
            int len = msg.Length;

            head[0] = (byte)(len % 0xff);
            len = (int)(len / 0xff);
            head[1] = (byte)(len % 0xff);
            len = (int)(len / 0xff);
            head[2] = (byte)(len % 0xff);
            len = (int)(len / 0xff);
            head[3] = (byte)(len % 0xff);

            Array.Copy(msg, 0, head, 4, msg.Length);

            return head;
        }

        /*public void Send(String msg)
        {
            if (BaedalItemList.socket != null)
            {
                try
                {
                    byte[] sendData = Encoding.UTF8.GetBytes(msg);
                    //byte[] data = setHeadData(sendData);

                    BaedalItemList.socket.Send(sendData, sendData.Length, SocketFlags.None);
                }
                catch (Exception ex)
                {
                    base.Completed -= Client_Completed;
                    Console.WriteLine($"Connection Error ({ex.Message})");
                    BaedalItemList.socket = null;
                }
            }
        }*/
        public void Send(Socket socket, String msg)
        {
            if (msg != null)
            {
                byte[] data = Encoding.UTF8.GetBytes(msg);

                BaedalItemList.socket.Send(data, data.Length, SocketFlags.None);
            }
            else
            {
                Console.WriteLine("message is null!!!");
            }
        }
    }

    class connect : Socket
    {
        public connect(string[] args) : base(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
        {

            var client = new Client(new IPEndPoint(IPAddress.Parse(args[0]), int.Parse(args[1])), args[2]);

            base.ConnectAsync(client);
            
            
            /*
            while (true)
            {
                string k = Console.ReadLine();

                client.Send(k + "\r\n");

                if ("exit".Equals(k, StringComparison.OrdinalIgnoreCase))
                    break;
                else if ("connect".Equals(k, StringComparison.OrdinalIgnoreCase))
                {
                    client = null;

                    client = new Client(new IPEndPoint(IPAddress.Parse(args[0]), int.Parse(args[1])));
                    base.ConnectAsync(client);
                }
            }
            */
        }
        
       
    }
}
