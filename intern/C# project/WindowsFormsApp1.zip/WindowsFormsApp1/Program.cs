﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaedalFriend.Model;
using BaedalFriend.Forms.Popup;

namespace BaedalFriend
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            BaedalItemList.frmLogin = new Form1();
            BaedalItemList.frmMain = new Form2();
            BaedalItemList.popAlarm = new popup_alarm();
            BaedalItemList.popCancel = new popup_order_cancel();
            BaedalItemList.popConfirm = new popup_order_confirm();

            Application.Run(BaedalItemList.frmLogin);
            BaedalItemList.popAlarm.Hide();
            BaedalItemList.popCancel.Hide();
            BaedalItemList.popConfirm.Hide();
            //BaedalItemList.frmLogin.Show();
            //BaedalItemList.frmMain.Hide();

            Regstry reg = new Regstry();
            reg.setBrowser();
        }
    }
}
