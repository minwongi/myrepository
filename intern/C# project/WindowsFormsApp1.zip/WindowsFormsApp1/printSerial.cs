﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;

namespace BaedalFriend
{
    class printSerial
    {

        Thread Serial_Receive;

        //public event Serial_MsgEventHandler Serial_MsgEvt;
        //public event Serial_DisconnectedEventHandler Serial_Disconnected;
        public event Serial_RcvMsgEventHandler Serial_RcvMsgEvt;
        //public event Serial_ConnectedEventHandler Serial_Connected;

        public delegate void Serial_MsgEventHandler(object sender, String rcvMsg, Boolean sMsgFlag);
        public delegate void Serial_DisconnectedEventHandler(object sender);
        public delegate void Serial_RcvMsgEventHandler(object sender, byte[] rcvMsg);
        public delegate void Serial_ConnectedEventHandler(object sender);
        public byte[] RecvData;

        SerialPort PortControl = new SerialPort();

        public void Serial_Received()
        {
            try
            {
                Serial_Receive = new Thread(new ThreadStart(Serial_ReceiveEvnt));
                Serial_Receive.IsBackground = true;
                Serial_Receive.Start();
            }
            catch (Exception)
            {
                return;
            }
        }

        public void Serial_ReceiveEvnt()
        {
            //수신 이벤트 설정
            PortControl.DataReceived += new SerialDataReceivedEventHandler(PortControl_DataReceived);
        }

        public bool OpenPort(string nPort_Num, int nBaudRate)
        {
            Console.WriteLine("연결 포트 : " + nPort_Num);
            try
            {
                if (nPort_Num.Length < 0)
                {
                    return false;
                }

                //COM포트 초기화
                PortControl.PortName = nPort_Num;
                PortControl.BaudRate = nBaudRate;
                PortControl.Parity = Parity.None;
                PortControl.StopBits = StopBits.One;
                PortControl.DataBits = 8;
                PortControl.Handshake = Handshake.RequestToSendXOnXOff;

                PortControl.Open();

                return true;

            }
            catch
            {
                return false;
            }
        }

        //데이터 수신 이벤트 핸들러
        public void PortControl_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            try
            {
                //리스트 두개 사용
                int nLnegth = 0;
                nLnegth = PortControl.BytesToRead;
                byte[] btTemp = new byte[nLnegth];
                PortControl.Read(btTemp, 0, nLnegth);

                if (nLnegth != 0)
                {
                    //수신된 데이터 처리.
                    Serial_RcvMsgEvt(this, btTemp);
                }

            }
            catch (Exception ex)
            {
                if (PortControl.IsOpen)
                {
                    System.Windows.Forms.MessageBox.Show(ex.ToString());
                }
                else
                {
                    return;
                }
            }

            //throw new NotImplementedException();
        }

        //Port Close
        public void ClosePort()
        {
            try
            {
                if (PortControl.IsOpen)
                {
                    PortControl.DataReceived -= new SerialDataReceivedEventHandler(PortControl_DataReceived);
                    PortControl.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }

        public void Recv_Data()
        {
            int nLnegth = 0;
            nLnegth = PortControl.BytesToRead;
            RecvData = new byte[nLnegth];
            PortControl.Read(RecvData, 0, nLnegth);

            //return RecvData;
        }

        public bool Send_Data(byte[] TxData)
        {
            try
            {
                PortControl.Write(TxData, 0, TxData.Length);
                return true;
            }
            catch (InvalidOperationException ie)
            {
                System.Windows.Forms.MessageBox.Show("포트가 닫혀 있습니다!!");
                return false;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
                return false;
            }

            //Send_Tx_Data(btTemp.Length, btTemp);
        }
        public void Send_txtData(string TxData)
        {
            try
            {
                PortControl.Write(TxData);
            }
            catch (InvalidOperationException ie)
            {
                System.Windows.Forms.MessageBox.Show("포트가 닫혀 있습니다!!");
                return;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
                return;
            }

            //Send_Tx_Data(btTemp.Length, btTemp);
        }

        public void SendTestData()
        {
            byte[] Buffer = new byte[8];

            Buffer[0] = 0x02;
            Buffer[1] = 0xF5;
            Buffer[2] = 0xF1;
            Buffer[3] = 0xFE;
            Buffer[4] = 0x00;
            Buffer[5] = 0x00;
            Buffer[6] = 0x03;

            PortControl.Write(Buffer, 0, 7);

        }
    }
}
