﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaedalFriend;
using BaedalFriend.Forms.Popup;
using BaedalFriend.socket.client;
using System.Net.Sockets;

namespace BaedalFriend.Model
{
    class BaedalItemList
    {
        static public Socket socket = null;
        static public connect client = null;
        static public Form1 frmLogin = null;
        static public Form2 frmMain = null;
        static public popup_alarm popAlarm = null;
        static public popup_order_cancel popCancel= null;
        static public popup_order_confirm popConfirm = null;
        static public popup_order popOrder= null;
        static public popup_cancel popCancel2= null;
        static public popup_order_deli popDeli= null;
        static public string mb_id = null;
        static public order orderfrm = null;
        static public store storefrm = null;
        static public register register = null;
        //프린터
        static public printSerial m_SerialPort = new printSerial();
    }
}
