﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace BaedalFriend
{
    class UrlRequest
    {
        public UrlRequest()
        {

        }

        public Boolean request(string url)
        {
            WebRequest request = WebRequest.Create(url);
            request.Method = "GET";

            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);

            string responseFromServer = reader.ReadToEnd();

            Console.WriteLine(responseFromServer); // response 출력

            reader.Close();
            dataStream.Close();
            response.Close();

            return true;
        }
    }
}
